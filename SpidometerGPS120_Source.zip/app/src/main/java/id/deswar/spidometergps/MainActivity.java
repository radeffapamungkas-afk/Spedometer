package id.deswar.spidometergps;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.graphics.*;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import android.content.Context;

public class MainActivity extends Activity {
    private LocationManager locationManager;
    private GaugeView gauge;
    private TextView status, accuracy, distanceText, maxText;
    private double distanceKm = 0, maxKmh = 0;
    private Location previous = null;
    private long startMs;
    private boolean tracking = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startMs = System.currentTimeMillis();
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(5, 8, 15));
        root.setPadding(dp(16), dp(16), dp(16), dp(12));

        TextView title = new TextView(this);
        title.setText("SPIDOMETER GPS");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setGravity(17);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        gauge = new GaugeView(this);
        root.addView(gauge, new LinearLayout.LayoutParams(-1, 0, 1f));

        status = makeText("Mencari sinyal GPS…", 16, Color.rgb(65, 235, 130));
        status.setGravity(17);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(36)));

        accuracy = makeText("Akurasi GPS: --", 14, Color.LTGRAY);
        accuracy.setGravity(17);
        root.addView(accuracy, new LinearLayout.LayoutParams(-1, dp(28)));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        distanceText = makeText("Jarak\n0.00 km", 16, Color.WHITE);
        maxText = makeText("Maksimum\n0 km/j", 16, Color.WHITE);
        distanceText.setGravity(17); maxText.setGravity(17);
        stats.addView(distanceText, new LinearLayout.LayoutParams(0, dp(64), 1f));
        stats.addView(maxText, new LinearLayout.LayoutParams(0, dp(64), 1f));
        root.addView(stats);

        TextView note = makeText("Gunakan di area terbuka. Angka berasal dari GPS, bukan sensor motor.", 11, Color.GRAY);
        note.setGravity(17);
        root.addView(note, new LinearLayout.LayoutParams(-1, dp(40)));
        setContentView(root);

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 20);
        } else startGps();
    }

    private TextView makeText(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 20 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startGps();
        else status.setText("Izin lokasi diperlukan untuk membaca kecepatan GPS");
    }

    private void startGps() {
        try {
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                status.setText("Aktifkan Lokasi/GPS di pengaturan HP");
            } else {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, listener, Looper.getMainLooper());
                status.setText("GPS aktif — menunggu satelit");
            }
        } catch (SecurityException e) { status.setText("Izin lokasi belum diberikan"); }
    }

    private final LocationListener listener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            float speed = loc.hasSpeed() ? loc.getSpeed() * 3.6f : 0f;
            // Reject obviously implausible GPS spikes.
            if (speed < 0 || speed > 300) return;
            if (previous != null) {
                float acc = loc.hasAccuracy() ? loc.getAccuracy() : 999;
                if (acc < 50) distanceKm += previous.distanceTo(loc) / 1000.0;
            }
            previous = loc;
            maxKmh = Math.max(maxKmh, speed);
            gauge.setSpeed(speed);
            float a = loc.hasAccuracy() ? loc.getAccuracy() : -1;
            accuracy.setText(a >= 0 ? String.format(java.util.Locale.US, "Akurasi GPS: ±%.0f meter", a) : "Akurasi GPS: belum tersedia");
            status.setText(a > 25 ? "GPS terdeteksi — akurasi sedang/rendah" : "GPS terhubung");
            distanceText.setText(String.format(java.util.Locale.US, "Jarak\\n%.2f km", distanceKm));
            maxText.setText(String.format(java.util.Locale.US, "Maksimum\\n%.0f km/j", maxKmh));
        }
        @Override public void onProviderEnabled(String provider) { status.setText("GPS diaktifkan"); }
        @Override public void onProviderDisabled(String provider) { status.setText("GPS mati — aktifkan Lokasi"); gauge.setSpeed(0); }
    };

    @Override protected void onPause() {
        super.onPause();
        try { if (locationManager != null) locationManager.removeUpdates(listener); } catch (Exception ignored) {}
    }
    @Override protected void onResume() {
        super.onResume();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) startGps();
    }

    private class GaugeView extends View {
        private final Paint p = new Paint(3);
        private float speed = 0;
        GaugeView(Context c) { super(c); }
        void setSpeed(float s) { speed = Math.min(120, Math.max(0, s)); invalidate(); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight(), cx=w/2f, cy=h*0.49f;
            float r=Math.min(w*0.44f, h*0.40f);
            c.drawColor(Color.rgb(5,8,15));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(12)); p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(38,48,66));
            c.drawArc(cx-r,cy-r,cx+r,cy+r,135,270,false,p);
            p.setColor(Color.rgb(0,170,255));
            c.drawArc(cx-r,cy-r,cx+r,cy+r,135,Math.min(270, speed/120f*270),false,p);

            for (int i=0;i<=24;i++) {
                float angle=(float)Math.toRadians(135+i*11.25);
                float inner=r-dp(i%2==0?25:16), outer=r-dp(2);
                float x1=cx+(float)Math.cos(angle)*inner, y1=cy+(float)Math.sin(angle)*inner;
                float x2=cx+(float)Math.cos(angle)*outer, y2=cy+(float)Math.sin(angle)*outer;
                p.setStrokeWidth(dp(i%2==0?3:1.5f));
                p.setColor(i*5 >= speed ? Color.LTGRAY : Color.rgb(0,190,255));
                c.drawLine(x1,y1,x2,y2,p);
                if(i%4==0) {
                    String label=String.valueOf(i*5);
                    p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(16));
                    p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.WHITE);
                    float tx=cx+(float)Math.cos(angle)*(r-dp(49)), ty=cy+(float)Math.sin(angle)*(r-dp(49))+dp(6);
                    c.drawText(label,tx,ty,p); p.setStyle(Paint.Style.STROKE);
                }
            }
            float needle=(float)Math.toRadians(135+speed/120f*270);
            p.setColor(Color.RED); p.setStrokeWidth(dp(4));
            c.drawLine(cx,cy,cx+(float)Math.cos(needle)*(r-dp(38)),cy+(float)Math.sin(needle)*(r-dp(38)),p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE);
            c.drawCircle(cx,cy,dp(8),p);
            p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(dp(58),w*0.16f)); p.setColor(Color.WHITE);
            c.drawText(String.format(java.util.Locale.US,"%.0f",speed),cx,cy+r*0.48f,p);
            p.setTextSize(dp(18)); p.setColor(Color.rgb(0,190,255));
            c.drawText("km/j",cx,cy+r*0.48f+dp(27),p);
            p.setTextSize(dp(12)); p.setColor(Color.LTGRAY);
            c.drawText("SKALA 0–120",cx,cy+r+dp(35),p);
        }
    }
}
