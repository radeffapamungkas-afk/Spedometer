# Spidometer GPS 120 — Android

Aplikasi Android native sederhana untuk membaca kecepatan dari GPS dan menampilkan spidometer 0–120 km/jam.

## Fitur
- Jarum dan angka kecepatan GPS real-time, skala 0–120 km/jam.
- Menampilkan perkiraan akurasi GPS dalam meter.
- Menghitung jarak perjalanan dan kecepatan maksimum selama aplikasi berjalan.
- Meminta izin lokasi saat pertama dibuka.

## Cara membuat APK
1. Instal Android Studio di PC/laptop.
2. Pilih **Open** lalu buka folder `SpidometerGPS120`.
3. Tunggu Gradle Sync selesai. Pastikan Android SDK Platform 35 terpasang.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke Android dan izinkan instalasi aplikasi dari sumber tersebut bila diminta.

## Catatan
- Proyek ini berisi kode sumber, belum berupa APK yang sudah dikompilasi.
- Untuk kompilasi diperlukan Android SDK dan Gradle/Android Studio.
- Kecepatan berasal dari GPS HP; bukan pembacaan ECU atau speed sensor motor. Hasil dapat terlambat/berubah jika sinyal lemah.
- Gunakan dengan dudukan yang aman dan jangan mengoperasikan HP saat berkendara.
